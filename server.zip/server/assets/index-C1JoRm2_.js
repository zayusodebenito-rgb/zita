import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { useState, useEffect, useRef } from "react";
import { O as OptimizedImage } from "./optimized-image-DeNDn9bm.js";
const THREE_SCRIPT_SRC = "https://cdnjs.cloudflare.com/ajax/libs/three.js/r134/three.min.js";
const VANTA_SCRIPT_SRC = "https://cdn.jsdelivr.net/npm/vanta@0.5.24/dist/vanta.net.min.js";
const scriptPromises = /* @__PURE__ */ new Map();
function loadScript(src) {
  if (typeof document === "undefined") return Promise.resolve();
  const existingScript = document.querySelector(`script[src="${src}"]`);
  if (existingScript?.dataset.loaded === "true") return Promise.resolve();
  if (scriptPromises.has(src)) {
    return scriptPromises.get(src);
  }
  const promise = new Promise((resolve, reject) => {
    const script = existingScript ?? document.createElement("script");
    script.src = src;
    script.async = true;
    script.defer = true;
    script.onload = () => {
      script.dataset.loaded = "true";
      resolve();
    };
    script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
    if (!existingScript) {
      document.head.appendChild(script);
    }
  });
  scriptPromises.set(src, promise);
  return promise;
}
function useScrollReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".fade-up");
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add("visible");
          observer.unobserve(e.target);
        }
      });
    }, {
      threshold: 0.12
    });
    els.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}
function VantaBackground() {
  const vantaRef = useRef(null);
  const vantaEffect = useRef(null);
  useEffect(() => {
    if (!vantaRef.current || vantaEffect.current) return;
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReducedMotion) return;
    let cancelled = false;
    loadScript(THREE_SCRIPT_SRC).then(() => loadScript(VANTA_SCRIPT_SRC)).then(() => {
      if (cancelled || !vantaRef.current || vantaEffect.current) return;
      const VANTA = window.VANTA;
      const THREE = window.THREE;
      if (!VANTA?.NET || !THREE) return;
      vantaEffect.current = VANTA.NET({
        el: vantaRef.current,
        THREE,
        mouseControls: true,
        touchControls: true,
        gyroControls: false,
        minHeight: 200,
        minWidth: 200,
        scale: 1,
        scaleMobile: 1,
        color: 16187647,
        backgroundColor: 2105376,
        points: 10,
        maxDistance: 15,
        spacing: 15,
        showDots: true
      });
    }).catch(() => {
    });
    return () => {
      cancelled = true;
      if (vantaEffect.current) {
        vantaEffect.current.destroy();
        vantaEffect.current = null;
      }
    };
  }, []);
  return /* @__PURE__ */ jsx("div", { ref: vantaRef, className: "vanta-background" });
}
function CustomCursor() {
  const cursorRef = useRef(null);
  const dotRef = useRef(null);
  useEffect(() => {
    const isTouchDevice = window.matchMedia("(hover: none)").matches || window.matchMedia("(pointer: coarse)").matches;
    if (isTouchDevice) return;
    const cursor = cursorRef.current;
    const dot = dotRef.current;
    if (!cursor || !dot) return;
    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;
    let cursorX = mouseX;
    let cursorY = mouseY;
    let animationFrameId;
    const moveCursor = (event) => {
      mouseX = event.clientX;
      mouseY = event.clientY;
      dot.style.transform = `translate(${mouseX}px, ${mouseY}px) translate(-50%, -50%)`;
    };
    const animateCursor = () => {
      cursorX += (mouseX - cursorX) * 0.16;
      cursorY += (mouseY - cursorY) * 0.16;
      cursor.style.transform = `translate(${cursorX}px, ${cursorY}px) translate(-50%, -50%)`;
      animationFrameId = requestAnimationFrame(animateCursor);
    };
    const showCursor = () => {
      cursor.classList.remove("is-hidden");
      dot.classList.remove("is-hidden");
    };
    const hideCursor = () => {
      cursor.classList.add("is-hidden");
      dot.classList.add("is-hidden");
    };
    const addHover = () => {
      cursor.classList.add("is-hovering");
    };
    const removeHover = () => {
      cursor.classList.remove("is-hovering");
    };
    const interactiveElements = document.querySelectorAll("a, button, .project-card, .service-card, input, textarea, select");
    interactiveElements.forEach((element) => {
      element.addEventListener("mouseenter", addHover);
      element.addEventListener("mouseleave", removeHover);
    });
    window.addEventListener("mousemove", moveCursor);
    document.addEventListener("mouseenter", showCursor);
    document.addEventListener("mouseleave", hideCursor);
    animateCursor();
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("mousemove", moveCursor);
      document.removeEventListener("mouseenter", showCursor);
      document.removeEventListener("mouseleave", hideCursor);
      interactiveElements.forEach((element) => {
        element.removeEventListener("mouseenter", addHover);
        element.removeEventListener("mouseleave", removeHover);
      });
    };
  }, []);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("div", { ref: cursorRef, className: "custom-cursor" }),
    /* @__PURE__ */ jsx("div", { ref: dotRef, className: "custom-cursor-dot" })
  ] });
}
const projects = [{
  id: 1,
  category: "Branding",
  title: "Identidad visual marca de cosmeticos",
  description: "Sistema visual con logotipo y fotografía profesional para redes sociales.",
  color: "#1a0d14",
  accent: "#FF4FA3",
  tag: "BRANDING",
  thumbnail: "/proyectos/identidad-cosmeticos/nebai-logo.jpg",
  images: [{
    title: "Logotipo",
    src: "/proyectos/identidad-cosmeticos/nebai-logo.jpg",
    variant: "photo"
  }, {
    title: "Fotografía",
    src: "/proyectos/identidad-cosmeticos/02-fotografia.jpg",
    variant: "photo"
  }, {
    title: "Fotografía",
    src: "/proyectos/identidad-cosmeticos/03-fotografia.jpg",
    variant: "photo"
  }, {
    title: "Fotografía",
    src: "/proyectos/identidad-cosmeticos/04-fotografia.jpg",
    variant: "photo"
  }, {
    title: "Fotografía",
    src: "/proyectos/identidad-cosmeticos/05-fotografia.jpg",
    variant: "photo"
  }, {
    title: "Fotografía",
    src: "/proyectos/identidad-cosmeticos/06-fotografia.jpg",
    variant: "photo"
  }, {
    title: "Fotografía",
    src: "/proyectos/identidad-cosmeticos/07-fotografia.jpg",
    variant: "photo"
  }, {
    title: "Fotografía",
    src: "/proyectos/identidad-cosmeticos/08-fotografia.jpg",
    variant: "photo"
  }, {
    title: "Fotografía",
    src: "/proyectos/identidad-cosmeticos/09-fotografia.jpg",
    variant: "photo"
  }, {
    title: "Fotografía",
    src: "/proyectos/identidad-cosmeticos/10-fotografia.jpg",
    variant: "photo"
  }, {
    title: "Fotografía",
    src: "/proyectos/identidad-cosmeticos/11-fotografia.jpg",
    variant: "photo"
  }, {
    title: "Fotografía",
    src: "/proyectos/identidad-cosmeticos/12-fotografia.jpg",
    variant: "photo"
  }]
}, {
  id: 2,
  category: "Social Media Design",
  title: "Campaña gráfica para redes sociales",
  description: "Diseño de piezas digitales coherentes para Instagram, stories y contenido promocional.",
  color: "#0d0d1a",
  accent: "#A78BFA",
  tag: "SOCIAL MEDIA",
  thumbnail: "/proyectos/campana-grafica/Slide_001.jpg",
  images: [{
    title: "Portada",
    src: "/proyectos/campana-grafica/Slide_001.jpg"
  }, {
    title: "Historia",
    src: "/proyectos/campana-grafica/Slide_002.jpg"
  }, {
    title: "Historia",
    src: "/proyectos/campana-grafica/Slide_003.jpg"
  }, {
    title: "Historia",
    src: "/proyectos/campana-grafica/Slide_004.jpg"
  }]
}, {
  id: 3,
  category: "Identidad visual",
  title: "Rediseño juego de mesa",
  description: "Dirección visual para un juego de mesa con cambio de identidad y con temática.",
  color: "#0f1a12",
  accent: "#34D399",
  tag: "IDENTIDAD",
  thumbnail: "/proyectos/redisenio-juego-mesa/portada-racks-city.png",
  images: [{
    title: "Logotipo",
    src: "/proyectos/redisenio-juego-mesa/portada-racks-city.png"
  }, {
    title: "Racks",
    src: "/proyectos/redisenio-juego-mesa/racks-500.jpg"
  }, {
    title: "Racks",
    src: "/proyectos/redisenio-juego-mesa/racks-200.jpg"
  }, {
    title: "Racks",
    src: "/proyectos/redisenio-juego-mesa/racks-1.jpg"
  }, {
    title: "Racks",
    src: "/proyectos/redisenio-juego-mesa/racks-5.jpg"
  }, {
    title: "Racks",
    src: "/proyectos/redisenio-juego-mesa/racks-10.jpg"
  }, {
    title: "Racks",
    src: "/proyectos/redisenio-juego-mesa/racks-20.jpg"
  }, {
    title: "Racks",
    src: "/proyectos/redisenio-juego-mesa/racks-50.jpg"
  }, {
    title: "Racks",
    src: "/proyectos/redisenio-juego-mesa/racks-100.jpg"
  }, {
    title: "Tablero",
    src: "/proyectos/redisenio-juego-mesa/tablero-racks-city.jpg",
    variant: "square"
  }]
}, {
  id: 4,
  category: "Diseño editorial",
  title: "Revista editorial proyecto personal",
  description: "Composición tipográfica y sistema gráfico para una revista.",
  color: "#1a1400",
  accent: "#FBBF24",
  tag: "EDITORIAL",
  thumbnail: "/proyectos/revista-editorial/Portada.jpg",
  images: [{
    title: "Portada y contraportada",
    src: "/proyectos/revista-editorial/Portada.jpg"
  }, {
    title: "Indice",
    src: "/proyectos/revista-editorial/Indice.jpg"
  }, {
    title: "Contenido",
    src: "/proyectos/revista-editorial/Contenido.jpg"
  }, {
    title: "Contenido",
    src: "/proyectos/revista-editorial/Contenido 2.jpg"
  }, {
    title: "Contenido",
    src: "/proyectos/revista-editorial/Contenido 3.jpg"
  }, {
    title: "Contenido",
    src: "/proyectos/revista-editorial/Contenido 4.jpg"
  }]
}, {
  id: 5,
  category: "Diseño interactivo",
  title: "Diseño aplicación móvil - Hold",
  description: "Sistema visual completo con logotipo, paleta de colores, tipografías y funcionalidad de la app.",
  color: "#10151f",
  accent: "#60A5FA",
  tag: "APP",
  thumbnail: "/proyectos/hold/portada-hold.png",
  images: [{
    title: "APP",
    src: "/proyectos/hold/Slide_001.jpg"
  }, {
    title: "APP",
    src: "/proyectos/hold/Slide_002.jpg"
  }, {
    title: "APP",
    src: "/proyectos/hold/Slide_003.jpg"
  }]
}];
const services = [{
  icon: "◈",
  title: "Branding e identidad visual",
  desc: "Creación de sistemas visuales completos: logotipo, paleta, tipografía y guía de estilo."
}, {
  icon: "◉",
  title: "Diseño para redes sociales",
  desc: "Piezas gráficas coherentes y atractivas para feed, stories y contenido digital."
}, {
  icon: "▦",
  title: "Diseño editorial",
  desc: "Composición tipográfica y visual para publicaciones, catálogos y revistas."
}, {
  icon: "◎",
  title: "Edición de video",
  desc: "Edición y creación de videos dinamicos y estrategicos para proyectos."
}, {
  icon: "⬡",
  title: "Manuales de marca o presentaciones",
  desc: "Creación de manual creativo de marca y presentaciones de alto impacto."
}, {
  icon: "↺",
  title: "Rebranding",
  desc: "Evolución o transformación completa de la identidad visual de una marca."
}];
const highlights = [{
  label: "Branding",
  num: "01"
}, {
  label: "Identidad visual",
  num: "02"
}, {
  label: "Diseño para redes",
  num: "03"
}, {
  label: "Dirección de arte",
  num: "04"
}];
function ProjectPlaceholder({
  color,
  accent
}) {
  return /* @__PURE__ */ jsxs("svg", { width: "100%", height: "100%", viewBox: "0 0 600 400", xmlns: "http://www.w3.org/2000/svg", style: {
    background: color,
    display: "block"
  }, children: [
    /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsxs("radialGradient", { id: `rg-${accent.replace("#", "")}`, cx: "30%", cy: "40%", r: "70%", children: [
      /* @__PURE__ */ jsx("stop", { offset: "0%", stopColor: accent, stopOpacity: "0.2" }),
      /* @__PURE__ */ jsx("stop", { offset: "100%", stopColor: "transparent", stopOpacity: "0" })
    ] }) }),
    /* @__PURE__ */ jsx("rect", { width: "600", height: "400", fill: `url(#rg-${accent.replace("#", "")})` }),
    /* @__PURE__ */ jsx("circle", { cx: "300", cy: "180", r: "120", fill: "none", stroke: accent, strokeOpacity: "0.15", strokeWidth: "1" }),
    /* @__PURE__ */ jsx("circle", { cx: "300", cy: "180", r: "80", fill: "none", stroke: accent, strokeOpacity: "0.1", strokeWidth: "0.5" }),
    /* @__PURE__ */ jsx("rect", { x: "240", y: "140", width: "120", height: "80", fill: "none", stroke: accent, strokeOpacity: "0.2", strokeWidth: "1" }),
    /* @__PURE__ */ jsx("text", { x: "300", y: "350", textAnchor: "middle", fontSize: "10", fontFamily: "sans-serif", fill: accent, fillOpacity: "0.5", letterSpacing: "4", children: "PROYECTO · DISEÑO GRÁFICO" })
  ] });
}
function ProjectGalleryModal({
  isOpen,
  selectedProject,
  onClose,
  onSelectProject
}) {
  useEffect(() => {
    if (!isOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const handleKeyDown = (event) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen, onClose]);
  if (!isOpen) return null;
  return /* @__PURE__ */ jsx("div", { className: "project-modal-overlay", role: "presentation", onMouseDown: onClose, children: /* @__PURE__ */ jsxs("section", { className: "project-modal", role: "dialog", "aria-modal": "true", "aria-labelledby": "project-modal-title", onMouseDown: (event) => event.stopPropagation(), children: [
    /* @__PURE__ */ jsx("button", { type: "button", className: "project-modal-close", onClick: onClose, "aria-label": "Cerrar proyectos", children: /* @__PURE__ */ jsxs("svg", { width: "22", height: "22", viewBox: "0 0 22 22", fill: "none", children: [
      /* @__PURE__ */ jsx("line", { x1: "5", y1: "5", x2: "17", y2: "17", stroke: "currentColor", strokeWidth: "1.7", strokeLinecap: "round" }),
      /* @__PURE__ */ jsx("line", { x1: "17", y1: "5", x2: "5", y2: "17", stroke: "currentColor", strokeWidth: "1.7", strokeLinecap: "round" })
    ] }) }),
    /* @__PURE__ */ jsxs("aside", { className: "project-modal-sidebar", children: [
      /* @__PURE__ */ jsx("span", { className: "project-modal-eyebrow", children: "Proyectos" }),
      /* @__PURE__ */ jsx("h2", { id: "project-modal-title", className: "project-modal-heading", children: "Galeria de trabajos" }),
      /* @__PURE__ */ jsx("div", { className: "project-modal-list", children: projects.map((project) => /* @__PURE__ */ jsxs("button", { type: "button", className: `project-modal-tab ${project.id === selectedProject.id ? "is-active" : ""}`, onClick: () => onSelectProject(project), style: {
        "--project-accent": project.accent
      }, children: [
        /* @__PURE__ */ jsx("span", { children: project.tag }),
        project.title
      ] }, project.id)) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "project-modal-content", children: [
      /* @__PURE__ */ jsxs("div", { className: "project-modal-intro", children: [
        /* @__PURE__ */ jsx("span", { style: {
          color: selectedProject.accent
        }, children: selectedProject.category }),
        /* @__PURE__ */ jsx("h3", { children: selectedProject.title }),
        /* @__PURE__ */ jsx("p", { children: selectedProject.description })
      ] }),
      /* @__PURE__ */ jsx("div", { className: `project-modal-images ${selectedProject.id === 1 ? "project-modal-images-cosmeticos" : selectedProject.id === 4 || selectedProject.id === 5 ? "project-modal-images-single" : selectedProject.id === 3 ? "project-modal-images-racks" : ""}`, children: selectedProject.images.map((image, index) => /* @__PURE__ */ jsxs("figure", { className: `project-modal-image ${"variant" in image ? `project-modal-image-${image.variant}` : ""}`, children: [
        image.src ? /* @__PURE__ */ jsx(OptimizedImage, { src: image.src, alt: `${selectedProject.title} - ${image.title}`, loading: index === 0 ? "eager" : "lazy", decoding: "async", width: image.variant === "square" ? 1200 : 1600, height: image.variant === "square" ? 1200 : 1e3, sizes: "(max-width: 767px) calc(100vw - 2.5rem), min(760px, 70vw)" }) : /* @__PURE__ */ jsx(ProjectPlaceholder, { color: selectedProject.color, accent: selectedProject.accent }),
        /* @__PURE__ */ jsx("figcaption", { children: image.title })
      ] }, `${selectedProject.id}-${image.title}-${index}`)) })
    ] })
  ] }) });
}
function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);
  return /* @__PURE__ */ jsxs("nav", { style: {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    zIndex: 50,
    transition: "background 0.3s, border-color 0.3s",
    borderBottom: scrolled ? "1px solid rgba(255,255,255,0.08)" : "1px solid transparent",
    background: scrolled ? "rgba(11,11,15,0.92)" : "transparent",
    backdropFilter: "blur(20px)"
  }, children: [
    /* @__PURE__ */ jsxs("div", { style: {
      maxWidth: "1200px",
      margin: "0 auto",
      padding: "0 1.5rem"
    }, children: [
      /* @__PURE__ */ jsxs("div", { style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        height: "72px"
      }, children: [
        /* @__PURE__ */ jsxs("a", { href: "#", style: {
          textDecoration: "none",
          display: "inline-flex",
          alignItems: "center",
          gap: "0.55rem"
        }, children: [
          /* @__PURE__ */ jsx("img", { src: "/logotipo-portfolio.svg", alt: "Logotipo Zita", width: "20", height: "25", decoding: "async", style: {
            width: "20px",
            height: "25px",
            display: "block"
          } }),
          /* @__PURE__ */ jsxs("span", { className: "font-display", style: {
            fontSize: "1.25rem",
            fontWeight: 800,
            color: "#F5F2F0",
            letterSpacing: "-0.02em"
          }, children: [
            "Zita",
            /* @__PURE__ */ jsx("span", { style: {
              color: "var(--pink)"
            }, children: "." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("ul", { style: {
          display: "flex",
          gap: "2.5rem",
          listStyle: "none",
          alignItems: "center"
        }, className: "hidden-mobile", children: [
          ["Proyectos", "Servicios", "Contacto"].map((item) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", { href: `#${item.toLowerCase()}`, style: {
            color: "rgba(245,242,240,0.7)",
            textDecoration: "none",
            fontSize: "0.875rem",
            fontWeight: 500,
            letterSpacing: "0.02em",
            transition: "color 0.2s"
          }, onMouseEnter: (e) => e.currentTarget.style.color = "var(--pink)", onMouseLeave: (e) => e.currentTarget.style.color = "rgba(245,242,240,0.7)", children: item }) }, item)),
          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", { href: "#contacto", className: "btn-pink", style: {
            padding: "0.5rem 1.25rem",
            fontSize: "0.8rem"
          }, children: "Contactar" }) })
        ] }),
        /* @__PURE__ */ jsx("button", { onClick: () => setMenuOpen(!menuOpen), style: {
          background: "none",
          border: "none",
          cursor: "pointer",
          color: "#F5F2F0",
          padding: "0.5rem"
        }, className: "show-mobile", "aria-label": "Menú", children: /* @__PURE__ */ jsx("svg", { width: "22", height: "22", viewBox: "0 0 22 22", fill: "none", children: menuOpen ? /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx("line", { x1: "4", y1: "4", x2: "18", y2: "18", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round" }),
          /* @__PURE__ */ jsx("line", { x1: "18", y1: "4", x2: "4", y2: "18", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round" })
        ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx("line", { x1: "3", y1: "6", x2: "19", y2: "6", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round" }),
          /* @__PURE__ */ jsx("line", { x1: "3", y1: "11", x2: "19", y2: "11", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round" }),
          /* @__PURE__ */ jsx("line", { x1: "3", y1: "16", x2: "19", y2: "16", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round" })
        ] }) }) })
      ] }),
      menuOpen && /* @__PURE__ */ jsx("div", { style: {
        padding: "1rem 0 1.5rem",
        borderTop: "1px solid rgba(255,255,255,0.08)",
        display: "flex",
        flexDirection: "column",
        gap: "1rem"
      }, children: ["Proyectos", "Servicios", "Contacto"].map((item) => /* @__PURE__ */ jsx("a", { href: `#${item.toLowerCase()}`, onClick: () => setMenuOpen(false), style: {
        color: "rgba(245,242,240,0.8)",
        textDecoration: "none",
        fontSize: "1rem",
        fontWeight: 500
      }, children: item }, item)) })
    ] }),
    /* @__PURE__ */ jsx("style", { children: `
        @media (min-width: 768px) { .hidden-mobile { display: flex !important; } .show-mobile { display: none !important; } }
        @media (max-width: 767px) { .hidden-mobile { display: none !important; } .show-mobile { display: block !important; } }
      ` })
  ] });
}
function Hero({
  onOpenProjects
}) {
  return /* @__PURE__ */ jsxs("section", { id: "hero", style: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    position: "relative",
    overflow: "hidden",
    paddingTop: "72px"
  }, children: [
    /* @__PURE__ */ jsx("div", { style: {
      position: "absolute",
      top: "15%",
      right: "-10%",
      width: "500px",
      height: "500px",
      background: "radial-gradient(circle, rgba(255,79,163,0.12) 0%, transparent 70%)",
      pointerEvents: "none",
      borderRadius: "50%"
    } }),
    /* @__PURE__ */ jsx("div", { style: {
      position: "absolute",
      bottom: "10%",
      left: "-15%",
      width: "400px",
      height: "400px",
      background: "radial-gradient(circle, rgba(255,79,163,0.06) 0%, transparent 70%)",
      pointerEvents: "none",
      borderRadius: "50%"
    } }),
    /* @__PURE__ */ jsx("div", { style: {
      position: "absolute",
      inset: 0,
      backgroundImage: "linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)",
      backgroundSize: "80px 80px",
      pointerEvents: "none"
    } }),
    /* @__PURE__ */ jsxs("div", { style: {
      maxWidth: "1200px",
      margin: "0 auto",
      padding: "4rem 1.5rem",
      position: "relative",
      zIndex: 1,
      width: "100%"
    }, children: [
      /* @__PURE__ */ jsx("div", { style: {
        marginBottom: "2rem"
      }, children: /* @__PURE__ */ jsx("span", { style: {
        display: "inline-block",
        fontSize: "0.7rem",
        fontWeight: 600,
        letterSpacing: "0.2em",
        color: "var(--pink)",
        border: "1px solid rgba(255,79,163,0.3)",
        borderRadius: "100px",
        padding: "0.4rem 1rem",
        background: "rgba(255,79,163,0.06)"
      }, children: "GRAPHIC DESIGN · PORTFOLIO" }) }),
      /* @__PURE__ */ jsxs("h1", { className: "font-display fade-up", style: {
        fontSize: "clamp(2.5rem, 6vw, 5.5rem)",
        fontWeight: 800,
        lineHeight: 1.05,
        letterSpacing: "-0.03em",
        maxWidth: "820px",
        marginBottom: "1.5rem"
      }, children: [
        "Cada proyecto tiene una historia.",
        " ",
        /* @__PURE__ */ jsx("span", { className: "unlock-text", children: "Poténciala." })
      ] }),
      /* @__PURE__ */ jsx("div", { style: {
        width: "80px",
        height: "3px",
        background: "linear-gradient(90deg, var(--pink), var(--pink-light))",
        borderRadius: "2px",
        marginBottom: "1.75rem",
        boxShadow: "0 0 20px rgba(255,79,163,0.5)"
      } }),
      /* @__PURE__ */ jsx("p", { className: "fade-up", style: {
        fontSize: "clamp(1rem, 2vw, 1.2rem)",
        color: "rgba(245,242,240,0.6)",
        maxWidth: "560px",
        lineHeight: 1.7,
        marginBottom: "2.5rem"
      }, children: "Diseño identidades visuales y piezas gráficas que ayudan a comunicar con claridad, personalidad y de forma coherente. Combinando estrategia, estética y atención a los detalles, para crear soluciones visuales funcionales y creativas." }),
      /* @__PURE__ */ jsxs("div", { className: "fade-up", style: {
        display: "flex",
        gap: "1rem",
        flexWrap: "wrap",
        alignItems: "center"
      }, children: [
        /* @__PURE__ */ jsxs("button", { type: "button", onClick: onOpenProjects, className: "btn-pink", children: [
          "Ver proyectos",
          /* @__PURE__ */ jsx("svg", { width: "16", height: "16", viewBox: "0 0 16 16", fill: "none", children: /* @__PURE__ */ jsx("path", { d: "M3 8h10M9 4l4 4-4 4", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" }) })
        ] }),
        /* @__PURE__ */ jsx("a", { href: "#contacto", className: "btn-outline", children: "Contactar" })
      ] }),
      /* @__PURE__ */ jsxs("div", { style: {
        marginTop: "5rem",
        display: "flex",
        alignItems: "center",
        gap: "0.75rem"
      }, children: [
        /* @__PURE__ */ jsx("div", { style: {
          width: "1px",
          height: "48px",
          background: "linear-gradient(to bottom, transparent, var(--pink), transparent)",
          opacity: 0.6
        } }),
        /* @__PURE__ */ jsx("span", { style: {
          fontSize: "0.7rem",
          letterSpacing: "0.15em",
          color: "rgba(245,242,240,0.4)",
          textTransform: "uppercase"
        }, children: "Scroll" })
      ] })
    ] })
  ] });
}
function Highlights() {
  return /* @__PURE__ */ jsx("section", { style: {
    padding: "2rem 0",
    background: "#202020",
    borderTop: "1px solid rgba(255,255,255,0.06)",
    borderBottom: "1px solid rgba(255,255,255,0.06)"
  }, children: /* @__PURE__ */ jsx("div", { style: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "0 1.5rem"
  }, children: /* @__PURE__ */ jsx("div", { style: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
    gap: "0"
  }, children: highlights.map((h, i) => /* @__PURE__ */ jsxs("div", { style: {
    padding: "1.75rem 2rem",
    borderRight: i < highlights.length - 1 ? "1px solid rgba(255,255,255,0.06)" : "none",
    display: "flex",
    flexDirection: "column",
    gap: "0.25rem"
  }, children: [
    /* @__PURE__ */ jsx("span", { style: {
      fontSize: "0.7rem",
      fontWeight: 700,
      color: "var(--pink)",
      letterSpacing: "0.1em"
    }, children: h.num }),
    /* @__PURE__ */ jsx("span", { style: {
      fontSize: "1rem",
      fontWeight: 600,
      color: "#F5F2F0",
      letterSpacing: "-0.01em"
    }, children: h.label })
  ] }, h.num)) }) }) });
}
function Projects({
  onOpenProject
}) {
  return /* @__PURE__ */ jsx("section", { id: "proyectos", style: {
    padding: "8rem 0"
  }, children: /* @__PURE__ */ jsxs("div", { style: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "0 1.5rem"
  }, children: [
    /* @__PURE__ */ jsxs("div", { className: "fade-up", style: {
      marginBottom: "4rem"
    }, children: [
      /* @__PURE__ */ jsx("div", { className: "section-divider" }),
      /* @__PURE__ */ jsx("span", { style: {
        fontSize: "0.75rem",
        fontWeight: 600,
        letterSpacing: "0.2em",
        color: "var(--pink)",
        textTransform: "uppercase"
      }, children: "Proyectos destacados" }),
      /* @__PURE__ */ jsx("h2", { className: "font-display", style: {
        fontSize: "clamp(2rem, 4vw, 3rem)",
        fontWeight: 800,
        marginTop: "0.75rem",
        letterSpacing: "-0.03em"
      }, children: "Trabajos" })
    ] }),
    /* @__PURE__ */ jsx("div", { style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
      gap: "1.5rem"
    }, children: projects.map((p, i) => /* @__PURE__ */ jsxs("div", { className: "project-card fade-up", onClick: () => onOpenProject(p), style: {
      background: p.color,
      borderRadius: "1.25rem",
      overflow: "hidden",
      cursor: "pointer"
    }, children: [
      /* @__PURE__ */ jsxs("div", { style: {
        aspectRatio: "16/10",
        position: "relative",
        overflow: "hidden",
        border: "4px solid rgba(245,242,240,0.2)",
        borderRadius: "1rem",
        margin: "0.85rem"
      }, children: [
        "thumbnail" in p && p.thumbnail ? /* @__PURE__ */ jsx(OptimizedImage, { src: p.thumbnail, alt: p.title, loading: "lazy", decoding: "async", width: 960, height: 600, sizes: "(max-width: 767px) calc(100vw - 3rem), (max-width: 1200px) calc((100vw - 6rem) / 2), 360px", pictureStyle: {
          display: "block",
          width: "100%",
          height: "100%"
        }, style: {
          display: "block",
          width: "100%",
          height: "100%",
          objectFit: "cover"
        } }) : /* @__PURE__ */ jsx(ProjectPlaceholder, { color: p.color, accent: p.accent }),
        /* @__PURE__ */ jsx("div", { style: {
          position: "absolute",
          top: "1rem",
          left: "1rem"
        }, children: /* @__PURE__ */ jsx("span", { style: {
          fontSize: "0.65rem",
          fontWeight: 700,
          letterSpacing: "0.12em",
          color: "#fff",
          border: `1px solid ${p.accent}CC`,
          background: `${p.accent}78`,
          boxShadow: "0 8px 24px rgba(0,0,0,0.25)",
          padding: "0.3rem 0.75rem",
          borderRadius: "100px"
        }, children: p.tag }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { style: {
        padding: "1.5rem"
      }, children: [
        /* @__PURE__ */ jsx("p", { style: {
          fontSize: "0.75rem",
          color: "rgba(245,242,240,0.45)",
          marginBottom: "0.4rem",
          letterSpacing: "0.05em"
        }, children: p.category }),
        /* @__PURE__ */ jsx("h3", { style: {
          fontSize: "1.05rem",
          fontWeight: 700,
          color: "#F5F2F0",
          marginBottom: "0.75rem",
          lineHeight: 1.3
        }, children: p.title }),
        /* @__PURE__ */ jsx("p", { style: {
          fontSize: "0.875rem",
          color: "rgba(245,242,240,0.55)",
          lineHeight: 1.6,
          marginBottom: "1.25rem"
        }, children: p.description }),
        /* @__PURE__ */ jsxs("button", { type: "button", onClick: (event) => {
          event.stopPropagation();
          onOpenProject(p);
        }, style: {
          background: "none",
          border: "none",
          color: p.accent,
          fontSize: "0.8rem",
          fontWeight: 600,
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: "0.4rem",
          padding: 0,
          letterSpacing: "0.02em"
        }, children: [
          "Ver proyecto",
          /* @__PURE__ */ jsx("svg", { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none", children: /* @__PURE__ */ jsx("path", { d: "M2 7h10M8 3l4 4-4 4", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" }) })
        ] })
      ] })
    ] }, p.id)) })
  ] }) });
}
function Services() {
  return /* @__PURE__ */ jsx("section", { id: "servicios", style: {
    padding: "8rem 0"
  }, children: /* @__PURE__ */ jsxs("div", { style: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "0 1.5rem"
  }, children: [
    /* @__PURE__ */ jsxs("div", { className: "fade-up", style: {
      marginBottom: "4rem",
      maxWidth: "600px"
    }, children: [
      /* @__PURE__ */ jsx("div", { className: "section-divider" }),
      /* @__PURE__ */ jsx("span", { style: {
        fontSize: "0.75rem",
        fontWeight: 600,
        letterSpacing: "0.2em",
        color: "var(--pink)",
        textTransform: "uppercase"
      }, children: "Que ofrezco" }),
      /* @__PURE__ */ jsx("h2", { className: "font-display", style: {
        fontSize: "clamp(2rem, 4vw, 3rem)",
        fontWeight: 800,
        marginTop: "0.75rem",
        letterSpacing: "-0.03em"
      }, children: "Mis servicios" }),
      /* @__PURE__ */ jsx("p", { style: {
        color: "rgba(245,242,240,0.55)",
        lineHeight: 1.7,
        marginTop: "1rem"
      }, children: "Diseño gráfico enfocado en la construcción de piezas visuales coherentes, atractivas y comunicativas." })
    ] }),
    /* @__PURE__ */ jsx("div", { style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
      gap: "1rem"
    }, children: services.map((s, i) => /* @__PURE__ */ jsxs("div", { className: "service-card fade-up", style: {
      padding: "2rem"
    }, children: [
      /* @__PURE__ */ jsx("div", { style: {
        width: "44px",
        height: "44px",
        background: "rgba(255,79,163,0.1)",
        border: "1px solid rgba(255,79,163,0.2)",
        borderRadius: "10px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "1.2rem",
        color: "var(--pink)",
        marginBottom: "1.25rem"
      }, children: s.icon }),
      /* @__PURE__ */ jsx("h3", { style: {
        fontSize: "1rem",
        fontWeight: 700,
        color: "#F5F2F0",
        marginBottom: "0.5rem",
        lineHeight: 1.3
      }, children: s.title }),
      /* @__PURE__ */ jsx("p", { style: {
        fontSize: "0.875rem",
        color: "rgba(245,242,240,0.5)",
        lineHeight: 1.65
      }, children: s.desc })
    ] }, s.title)) })
  ] }) });
}
function About() {
  return /* @__PURE__ */ jsx("section", { style: {
    padding: "8rem 0",
    background: "rgba(255,79,163,0.02)",
    borderTop: "1px solid rgba(255,255,255,0.05)",
    borderBottom: "1px solid rgba(255,255,255,0.05)"
  }, children: /* @__PURE__ */ jsx("div", { style: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "0 1.5rem"
  }, children: /* @__PURE__ */ jsxs("div", { style: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
    gap: "4rem",
    alignItems: "center"
  }, children: [
    /* @__PURE__ */ jsxs("div", { className: "fade-up", children: [
      /* @__PURE__ */ jsx("div", { className: "section-divider" }),
      /* @__PURE__ */ jsx("span", { style: {
        fontSize: "0.75rem",
        fontWeight: 600,
        letterSpacing: "0.2em",
        color: "var(--pink)",
        textTransform: "uppercase"
      }, children: "Sobre mí" }),
      /* @__PURE__ */ jsx("h2", { className: "font-display", style: {
        fontSize: "clamp(2rem, 4vw, 3rem)",
        fontWeight: 800,
        marginTop: "0.75rem",
        letterSpacing: "-0.03em",
        marginBottom: "1.5rem"
      }, children: "Zita Ayuso" }),
      /* @__PURE__ */ jsx("p", { style: {
        fontSize: "1.05rem",
        color: "rgba(245,242,240,0.7)",
        lineHeight: 1.8,
        marginBottom: "2rem"
      }, children: "Estudiante de diseño gráfico, estoy construyendo mi trayectoria profesional a través de proyectos creativos estrategicos y con una intención de comunicación. Me interesa crear identidades visuales creativas, cuidando los detalles y transformando mis ideas en soluciones gráficas funcionales y llamativas." }),
      /* @__PURE__ */ jsx("div", { style: {
        display: "flex",
        gap: "0.75rem",
        flexWrap: "wrap"
      }, children: ["Branding", "Identidad visual", "Social Media", "Editorial", "Dirección de arte"].map((tag) => /* @__PURE__ */ jsx("span", { style: {
        fontSize: "0.75rem",
        fontWeight: 600,
        color: "var(--pink)",
        border: "1px solid rgba(255,79,163,0.25)",
        background: "rgba(255,79,163,0.07)",
        padding: "0.35rem 0.85rem",
        borderRadius: "100px",
        letterSpacing: "0.04em"
      }, children: tag }, tag)) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "fade-up", style: {
      position: "relative"
    }, children: /* @__PURE__ */ jsxs("div", { style: {
      aspectRatio: "1",
      maxWidth: "400px",
      background: "var(--card)",
      borderRadius: "1.5rem",
      border: "1px solid rgba(255,255,255,0.07)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      position: "relative",
      overflow: "hidden"
    }, children: [
      /* @__PURE__ */ jsx("div", { style: {
        position: "absolute",
        inset: 0,
        background: "radial-gradient(ellipse at 30% 30%, rgba(255,79,163,0.15), transparent 60%)"
      } }),
      /* @__PURE__ */ jsxs("div", { style: {
        textAlign: "center",
        position: "relative",
        zIndex: 1
      }, children: [
        /* @__PURE__ */ jsx("div", { className: "font-display", style: {
          fontSize: "5rem",
          fontWeight: 800,
          color: "rgba(255,79,163,0.2)",
          lineHeight: 1
        }, children: "ZA" }),
        /* @__PURE__ */ jsx("p", { style: {
          fontSize: "0.75rem",
          letterSpacing: "0.3em",
          color: "rgba(245,242,240,0.3)",
          textTransform: "uppercase",
          marginTop: "0.5rem"
        }, children: "Diseño gráfico" })
      ] }),
      /* @__PURE__ */ jsx("div", { style: {
        position: "absolute",
        top: "1.5rem",
        right: "1.5rem",
        width: "40px",
        height: "40px",
        border: "1px solid rgba(255,79,163,0.3)",
        borderRadius: "50%"
      } }),
      /* @__PURE__ */ jsx("div", { style: {
        position: "absolute",
        bottom: "2rem",
        left: "2rem"
      }, children: /* @__PURE__ */ jsx("div", { style: {
        width: "3px",
        height: "40px",
        background: "linear-gradient(to bottom, var(--pink), transparent)",
        borderRadius: "2px"
      } }) })
    ] }) })
  ] }) }) });
}
function EmailSpotlightModal({
  isOpen,
  onClose
}) {
  const [copied, setCopied] = useState(false);
  const email = "zayusodebenito@gmail.com";
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (event) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);
  if (!isOpen) return null;
  const copyEmail = async () => {
    await navigator.clipboard.writeText(email);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  };
  return /* @__PURE__ */ jsx("div", { className: "email-modal-overlay", role: "presentation", onMouseDown: onClose, children: /* @__PURE__ */ jsxs("div", { className: "email-spotlight", role: "dialog", "aria-modal": "true", "aria-label": "Correo de contacto", onMouseDown: (event) => event.stopPropagation(), children: [
    /* @__PURE__ */ jsxs("div", { className: "email-spotlight-field", children: [
      /* @__PURE__ */ jsxs("svg", { width: "18", height: "18", viewBox: "0 0 18 18", fill: "none", "aria-hidden": "true", children: [
        /* @__PURE__ */ jsx("path", { d: "M3 5h12v8H3V5Z", stroke: "currentColor", strokeWidth: "1.4", strokeLinejoin: "round" }),
        /* @__PURE__ */ jsx("path", { d: "M3 6l6 4 6-4", stroke: "currentColor", strokeWidth: "1.4", strokeLinecap: "round", strokeLinejoin: "round" })
      ] }),
      /* @__PURE__ */ jsx("span", { children: email })
    ] }),
    /* @__PURE__ */ jsx("button", { type: "button", className: "email-copy-button", onClick: copyEmail, "aria-label": "Copiar correo", children: copied ? /* @__PURE__ */ jsx("svg", { width: "18", height: "18", viewBox: "0 0 18 18", fill: "none", "aria-hidden": "true", children: /* @__PURE__ */ jsx("path", { d: "M4 9.4l3 3 7-7", stroke: "currentColor", strokeWidth: "1.7", strokeLinecap: "round", strokeLinejoin: "round" }) }) : /* @__PURE__ */ jsxs("svg", { width: "18", height: "18", viewBox: "0 0 18 18", fill: "none", "aria-hidden": "true", children: [
      /* @__PURE__ */ jsx("rect", { x: "6", y: "5", width: "8", height: "10", rx: "1.5", stroke: "currentColor", strokeWidth: "1.4" }),
      /* @__PURE__ */ jsx("path", { d: "M4 12.5V4.5A1.5 1.5 0 0 1 5.5 3H12", stroke: "currentColor", strokeWidth: "1.4", strokeLinecap: "round" })
    ] }) })
  ] }) });
}
function Contact() {
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("section", { id: "contacto", style: {
      padding: "10rem 0",
      position: "relative",
      overflow: "hidden"
    }, children: [
      /* @__PURE__ */ jsx("div", { style: {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%,-50%)",
        width: "600px",
        height: "400px",
        background: "radial-gradient(ellipse, rgba(255,79,163,0.08) 0%, transparent 70%)",
        pointerEvents: "none"
      } }),
      /* @__PURE__ */ jsx("div", { style: {
        maxWidth: "800px",
        margin: "0 auto",
        padding: "0 1.5rem",
        textAlign: "center",
        position: "relative",
        zIndex: 1
      }, children: /* @__PURE__ */ jsxs("div", { className: "fade-up", children: [
        /* @__PURE__ */ jsx("span", { style: {
          fontSize: "0.75rem",
          fontWeight: 600,
          letterSpacing: "0.2em",
          color: "var(--pink)",
          textTransform: "uppercase"
        }, children: "Contacto" }),
        /* @__PURE__ */ jsxs("h2", { className: "font-display", style: {
          fontSize: "clamp(2.2rem, 5vw, 4rem)",
          fontWeight: 800,
          marginTop: "1rem",
          marginBottom: "1.5rem",
          letterSpacing: "-0.03em",
          lineHeight: 1.1
        }, children: [
          "¿Creamos algo?",
          " ",
          /* @__PURE__ */ jsx("span", { className: "gradient-text", children: "Hablemos." })
        ] }),
        /* @__PURE__ */ jsx("p", { style: {
          fontSize: "1.05rem",
          color: "rgba(245,242,240,0.6)",
          lineHeight: 1.7,
          maxWidth: "560px",
          margin: "0 auto 3rem"
        }, children: "Si tienes un protecto o quieres saber más sobre mi trabajo, escríbeme." }),
        /* @__PURE__ */ jsxs("div", { style: {
          display: "flex",
          gap: "1rem",
          justifyContent: "center",
          flexWrap: "wrap"
        }, children: [
          /* @__PURE__ */ jsxs("button", { type: "button", onClick: () => setIsEmailModalOpen(true), className: "btn-pink", style: {
            fontSize: "0.9rem",
            padding: "0.875rem 2rem"
          }, children: [
            /* @__PURE__ */ jsxs("svg", { width: "18", height: "18", viewBox: "0 0 18 18", fill: "none", children: [
              /* @__PURE__ */ jsx("path", { d: "M3 4h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z", stroke: "currentColor", strokeWidth: "1.5" }),
              /* @__PURE__ */ jsx("path", { d: "M2 5l7 5 7-5", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round" })
            ] }),
            "Enviar email"
          ] }),
          /* @__PURE__ */ jsxs("a", { href: "https://www.instagram.com/ziitaayuso/", target: "_blank", rel: "noopener noreferrer", className: "btn-outline", style: {
            fontSize: "0.9rem",
            padding: "0.875rem 2rem"
          }, children: [
            /* @__PURE__ */ jsxs("svg", { width: "18", height: "18", viewBox: "0 0 18 18", fill: "none", children: [
              /* @__PURE__ */ jsx("rect", { x: "2", y: "2", width: "14", height: "14", rx: "4", stroke: "currentColor", strokeWidth: "1.5" }),
              /* @__PURE__ */ jsx("circle", { cx: "9", cy: "9", r: "3", stroke: "currentColor", strokeWidth: "1.5" }),
              /* @__PURE__ */ jsx("circle", { cx: "13.5", cy: "4.5", r: "0.75", fill: "currentColor" })
            ] }),
            "Ver Instagram"
          ] })
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsx(EmailSpotlightModal, { isOpen: isEmailModalOpen, onClose: () => setIsEmailModalOpen(false) })
  ] });
}
function Footer() {
  return /* @__PURE__ */ jsx("footer", { style: {
    borderTop: "1px solid rgba(255,255,255,0.06)",
    padding: "2.5rem 0",
    background: "rgba(0,0,0,0.3)"
  }, children: /* @__PURE__ */ jsxs("div", { style: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "0 1.5rem",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: "1rem"
  }, children: [
    /* @__PURE__ */ jsxs("span", { className: "font-display", style: {
      fontSize: "1.1rem",
      fontWeight: 800,
      letterSpacing: "-0.02em"
    }, children: [
      "Zita",
      /* @__PURE__ */ jsx("span", { style: {
        color: "var(--pink)"
      }, children: "." })
    ] }),
    /* @__PURE__ */ jsx("p", { style: {
      fontSize: "0.8rem",
      color: "rgba(245,242,240,0.35)"
    }, children: "© 2025 Zita Ayuso · Portfolio - Diseño gráfico" }),
    /* @__PURE__ */ jsx("div", { style: {
      display: "flex",
      gap: "1.5rem"
    }, children: ["Proyectos", "Servicios", "Contacto"].map((l) => /* @__PURE__ */ jsx("a", { href: `#${l.toLowerCase()}`, style: {
      fontSize: "0.8rem",
      color: "rgba(245,242,240,0.4)",
      textDecoration: "none",
      transition: "color 0.2s"
    }, onMouseEnter: (e) => e.currentTarget.style.color = "var(--pink)", onMouseLeave: (e) => e.currentTarget.style.color = "rgba(245,242,240,0.4)", children: l }, l)) })
  ] }) });
}
function ZitaPortfolio() {
  useScrollReveal();
  const [selectedProject, setSelectedProject] = useState(projects[0]);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const openProjectModal = (project = projects[0]) => {
    setSelectedProject(project);
    setIsProjectModalOpen(true);
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(VantaBackground, {}),
    /* @__PURE__ */ jsx(CustomCursor, {}),
    /* @__PURE__ */ jsx(Nav, {}),
    /* @__PURE__ */ jsxs("main", { children: [
      /* @__PURE__ */ jsx(Hero, { onOpenProjects: () => openProjectModal() }),
      /* @__PURE__ */ jsx(Highlights, {}),
      /* @__PURE__ */ jsx(Projects, { onOpenProject: openProjectModal }),
      /* @__PURE__ */ jsx(Services, {}),
      /* @__PURE__ */ jsx(About, {}),
      /* @__PURE__ */ jsx(Contact, {})
    ] }),
    /* @__PURE__ */ jsx(Footer, {}),
    /* @__PURE__ */ jsx(ProjectGalleryModal, { isOpen: isProjectModalOpen, selectedProject, onClose: () => setIsProjectModalOpen(false), onSelectProject: setSelectedProject })
  ] });
}
export {
  ZitaPortfolio as component
};
