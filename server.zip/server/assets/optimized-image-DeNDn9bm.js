import { jsxs, jsx } from "react/jsx-runtime";
function getVariantSrc(src, format) {
  if (!/\.(jpe?g|png)$/i.test(src)) return null;
  return src.replace(/\.(jpe?g|png)$/i, `.${format}`);
}
function OptimizedImage({ alt, pictureStyle, src, ...imgProps }) {
  const avifSrc = getVariantSrc(src, "avif");
  const webpSrc = getVariantSrc(src, "webp");
  return /* @__PURE__ */ jsxs("picture", { style: pictureStyle ?? { display: "block" }, children: [
    avifSrc && /* @__PURE__ */ jsx("source", { srcSet: avifSrc, type: "image/avif" }),
    webpSrc && /* @__PURE__ */ jsx("source", { srcSet: webpSrc, type: "image/webp" }),
    /* @__PURE__ */ jsx("img", { src, alt, ...imgProps })
  ] });
}
export {
  OptimizedImage as O
};
